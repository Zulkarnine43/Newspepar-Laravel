<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class category_add extends Model
{
    //
    protected $fillable=['Category_name','Category_description','Category_image'];

}
