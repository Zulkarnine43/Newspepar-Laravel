<h1>Your Blogger Password is:</h1>
<a href="{{route('admin_change_password')}}">Change password</a>
<h2>Thank You</h2>
