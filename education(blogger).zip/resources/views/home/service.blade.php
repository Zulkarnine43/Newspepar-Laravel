@extends('home.headerFooter3')
@section('body')

   <div class="banner-section">
    <div class="banner">
        <div class="b-bottom">
            <h5 class="top"><a href="single.html">What turn out consetetur sadipscing elit</a></h5>
        </div>
    </div>
    <!--//banner-->
    <!--/top-news-->
    <div class="top-news">
        <h3 class="tittle">Services <i class="glyphicon glyphicon-cog"></i></h3>
        <div class="top-inner">
            <div class="col-md-6 top-text">
                <a href="single.html"><img src="{{url('public/home/images/pic2.jpg')}}" class="img-responsive" alt=""></a>
                <div class="ser">
                    <h5 class="top"><a href="single.html">Consetetur sadipscing elit</a></h5>
                    <p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna aliquyam eratsed diam justo duo dolores rebum.</p>
                    <p>On Jun 27 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.html"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
                </div>
            </div>
            <div class="col-md-6 top-text two">
                <a href="single.html"><img src="{{url('public/home/images/pic1.jpg')}}" class="img-responsive" alt=""></a>
                <div class="ser">
                    <h5 class="top"><a href="single.html">Consetetur sadipscing elit</a></h5>
                    <p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna aliquyam eratsed diam justo duo dolores rebum.</p>
                    <p>On Jun 27 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.html"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="top-inner second">
            <div class="col-md-6 top-text">
                <a href="single.html"><img src="{{url('public/home/images/pic3.jpg')}}" class="img-responsive" alt=""></a>
                <div class="ser">
                    <h5 class="top"><a href="single.html">Consetetur sadipscing elit</a></h5>
                    <p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna aliquyam eratsed diam justo duo dolores rebum.</p>
                    <p>On Jun 27 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.html"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
                </div>
            </div>
            <div class="col-md-6 top-text two">
                <a href="single.html"><img src="{{url('public/home/images/pic4.jpg')}}" class="img-responsive" alt=""></a>
                <div class="ser">
                    <h5 class="top"><a href="single.html">Consetetur sadipscing elit</a></h5>
                    <p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna aliquyam eratsed diam justo duo dolores rebum.</p>
                    <p>On Jun 27 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.html"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
                </div>
            </div>
        </div>
    </div>
    <!--//top-news-->
    </div>
    @endsection
