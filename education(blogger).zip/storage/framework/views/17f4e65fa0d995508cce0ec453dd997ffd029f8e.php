<?php $__env->startSection('body'); ?>
    <link href="<?php echo e(url('public/css/manage.css')); ?>" rel="stylesheet" type="text/css">
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="m">Manage farmer Info</h3>
                    <table class="table table-bordered small text-center table-hover">
                        <tr class="t1">
                            <th>Sl No</th>
                            <th>fullname</th>
                            <th>email </th>
                            <th>mobile </th>
                            <th>district</th>
                            <th>Created_At</th>
                            <th>Action</th>
                        </tr>
                        <?php ($i=1); ?>;
                        <?php $__currentLoopData = $farm_infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farm_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="t2">
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($farm_info->fullname); ?></td>
                                <td><?php echo e($farm_info->email); ?></td>
                                <td><?php echo e($farm_info->mobile); ?></td>
                                <td><?php echo e($farm_info->district); ?></td>
                                <td><?php echo e($farm_info->created_at); ?></td>
                                <td>
                                    <span><a href="<?php echo e(route('admin_Show_Farmer_details',['email'=>$farm_info->email])); ?>">All_crops</a></span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.headerFooter', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>