
<p>I would be appriviative , if  gone through this feedback... </p>
<a href="<?php echo e(route('cust_registerVerify')); ?>">For verify Click Here</a>




